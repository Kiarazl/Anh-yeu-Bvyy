const CONFIG = {
    introTitle: 'Chúc mừng ngày 8/3 sớm nhé emiu!',
    introDesc: `Chiều chiều lại nhớ chiều chiều
Hôm nay anh nhớ em nhiều biết chăng
Chiều chiều lại nhớ chiều chiều
Lòng anh đang có đôi điều với em`,
    btnIntro: 'hihi',
    title: 'Em bée Nguỹn Hoèng Bẻo Zy àaaaaaaa',
    desc: 'Em bé có iu anh honggggg',
    btnYes: 'hơi hơi iu',
    btnNo: 'khom iu',
    question:'Sao em 0 iu thằng nào ăn chơi mà lại iu anh :D?',
    btnReply: 'đúng òiiiii',
    reply: 'tại anh đẹp trai học giỏi s1tg lại còn đc học bổng',
    mess: 'Anh biết mà 🥰. Yêu em bée 😘😘',
    messDesc: 'Tối mai học xong anh đi bộ qua nhà em bé nhó.',
    btnAccept: 'Okiiiii lun <3',
    messLink: 'https://m.me/61557848840544?hash=AbYjbi88EU8tMtJl&source=qr_link_share'
}